import Link from "next/link";
import { redirect } from "next/navigation";
import {
  ArrowRight,
  Bot,
  CheckCircle2,
  CreditCard,
  FileText,
  LineChart,
  ShieldCheck,
  Sparkles,
} from "lucide-react";
import { AgentTeamSection } from "@/components/AgentTeamSection";
import { BearMark } from "@/components/BearMark";
import { RevolvingStory } from "@/components/RevolvingStory";
import { FinanceLoopSection } from "@/components/FinanceLoopSection";
import { ScrollStage } from "@/components/ScrollMotion";
import { getSessionUser } from "@/lib/auth";

const STATS = [
  { label: "Cash-flow horizons", value: "7 / 30 / 90 days", icon: LineChart },
  { label: "Agents orchestrated", value: "5 specialists", icon: Bot },
  { label: "Payment rails", value: "PayPal + manual", icon: CreditCard },
  { label: "Reports", value: "PDF & CSV", icon: FileText },
];

export default async function LandingPage() {
  const user = await getSessionUser();
  if (user) redirect(user.onboardingComplete ? "/overview" : "/onboarding");

  return (
    <ScrollStage className="min-h-screen bg-white" distance={90} shift={46} floor={0.02}>
      <header className="site-header sticky top-0 z-30 border-b border-slate-200/70 bg-white/85 backdrop-blur">
        <div className="site-header-inner mx-auto flex max-w-6xl items-center justify-between px-4 py-3 sm:px-6">
          <div className="flex items-center gap-2">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-brand text-white shadow-lg shadow-brand/30">
              <BearMark className="h-[22px] w-[22px]" />
            </span>
            <div className="min-w-0">
              <p className="text-sm font-semibold text-navy">PayPilot AI</p>
              <p className="hidden text-[11px] text-slate-500 sm:block">Autonomous finance assistant</p>
            </div>
          </div>
          <nav className="hidden items-center gap-6 text-sm text-slate-600 md:flex">
            <a href="#agents" className="hover:text-navy">
              Agents
            </a>
            <a href="#workflow" className="hover:text-navy">
              Workflow
            </a>
            <a href="#platform" className="hover:text-navy">
              Platform
            </a>
          </nav>
          <div className="flex shrink-0 items-center gap-1.5 sm:gap-2">
            <Link href="/login" className="btn btn-secondary !px-3 !py-2 text-[13px] sm:!py-1.5 sm:text-sm">
              Sign in
            </Link>
            <Link href="/register" className="btn btn-primary !px-3 !py-2 text-[13px] sm:!px-4 sm:!py-1.5 sm:text-sm">
              Start free
            </Link>
          </div>
        </div>
        <div className="scroll-progress" data-scroll-progress aria-hidden="true" />
      </header>

      <section className="hero-glow relative flex min-h-[94vh] items-center overflow-hidden bg-navy text-white">
        <div
          data-scroll-drift="0.22"
          aria-hidden="true"
          className="pointer-events-none absolute -left-40 -top-48 h-[520px] w-[520px] rounded-full bg-brand/20 blur-[120px]"
        />
        <div
          data-scroll-drift="-0.12"
          aria-hidden="true"
          className="pointer-events-none absolute -right-32 top-32 h-[420px] w-[420px] rounded-full bg-[#009cde]/15 blur-[120px]"
        />
        <div className="relative mx-auto w-full max-w-4xl px-4 py-20 text-center sm:px-6">
          <span className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-3 py-1 text-xs font-medium text-slate-200">
            <Sparkles className="h-3.5 w-3.5 text-brand" /> Five collaborating AI agents · one virtual CFO
          </span>
          <h1 className="mt-5 text-4xl font-semibold leading-tight tracking-tight sm:text-5xl">
            Your autonomous finance assistant for the business you are building.
          </h1>
          <p className="mx-auto mt-4 max-w-2xl text-base text-slate-300 sm:text-lg">
            PayPilot AI connects your projects, quotations, invoices, payments and expenses — then predicts cash
            shortages, flags risky clients and recommends the exact actions to protect your runway.
          </p>
          <div className="mt-7 flex flex-wrap items-center justify-center gap-3">
            <Link href="/register" className="btn btn-primary !px-5 !py-3">
              Create your workspace <ArrowRight className="h-4 w-4" />
            </Link>
            <Link href="/api/auth/demo" className="btn !border !border-white/20 !bg-white/5 !px-5 !py-3 !text-white hover:!bg-white/10">
              Explore the live demo
            </Link>
          </div>
          <div className="mt-8 flex flex-wrap justify-center gap-x-8 gap-y-3 text-sm text-slate-300">
            <span className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-mint" /> Real calculations from your ledger
            </span>
            <span className="flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 text-mint" /> Human approval before any action
            </span>
            <span className="flex items-center gap-2">
              <Bot className="h-4 w-4 text-mint" /> Optional Gemini reasoning
            </span>
          </div>
          <p className="mt-6 text-[11px] font-semibold text-[#8fa6c9]">
            Scroll down: the agent network fills the next screen and powers up from 0 to 100% as you go.
          </p>
        </div>
      </section>

      <RevolvingStory />

      <section className="mx-auto max-w-6xl px-4 py-14 sm:px-6">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {STATS.map((item, index) => (
            <div key={item.label} data-scroll data-scroll-delay={index * 22} className="card card-hover p-5">
              <item.icon className="h-5 w-5 text-brand" />
              <p className="mt-3 text-lg font-semibold text-navy">{item.value}</p>
              <p className="text-sm text-slate-500">{item.label}</p>
            </div>
          ))}
        </div>
      </section>

      <AgentTeamSection />

      <FinanceLoopSection />

      <section className="bg-navy">
        <div className="mx-auto flex max-w-6xl flex-col items-start justify-between gap-4 px-4 py-14 sm:px-6 md:flex-row md:items-center">
          <div data-scroll>
            <h2 className="text-2xl font-semibold text-white">Ready to see your cash-flow risk in 60 seconds?</h2>
            <p className="mt-1 text-sm text-slate-300">
              Create an account and explore a fully loaded demo business with real calculations.
            </p>
          </div>
          <Link href="/register" data-scroll data-scroll-delay={60} className="btn btn-primary !px-5 !py-3">
            Start free <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>

      {/* The last thing on the page: deliberately not tied to scrolling. */}
      <footer data-scroll-end className="border-t border-slate-200 py-8">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-2 px-4 text-xs text-slate-500 sm:flex-row sm:px-6">
          <p>© {new Date().getFullYear()} PayPilot AI. Estimates are not guarantees of future financial outcomes.</p>
          <p>Built with Next.js, PostgreSQL, Gemini and PayPal.</p>
        </div>
      </footer>
    </ScrollStage>
  );
}
