import type { ReactNode } from "react";

export default function AuthLayout({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-navy px-4 py-10 hero-glow">
      <div className="w-full max-w-md">{children}</div>
    </div>
  );
}
