import { redirect } from "next/navigation";
import { AuthForm } from "@/components/AuthForm";
import { getSessionUser } from "@/lib/auth";

export default async function LoginPage() {
  const user = await getSessionUser();
  if (user) redirect(user.onboardingComplete ? "/overview" : "/onboarding");
  return <AuthForm mode="login" />;
}
