import { AuthForm } from "@/components/AuthForm";

export default async function ForgotPasswordPage({ searchParams }: { searchParams: Promise<{ token?: string }> }) {
  const { token = "" } = await searchParams;
  return <AuthForm mode="forgot" initialToken={token} />;
}
