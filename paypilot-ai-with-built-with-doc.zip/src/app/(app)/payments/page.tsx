import { PaymentsView } from "@/components/payments";

export default function PaymentsPage() {
  return <PaymentsView />;
}
