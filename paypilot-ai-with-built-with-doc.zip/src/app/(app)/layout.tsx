import { redirect } from "next/navigation";
import type { ReactNode } from "react";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { businesses } from "@/db/schema";
import { AppShell } from "@/components/AppShell";
import { getSessionUser } from "@/lib/auth";

export default async function AppLayout({ children }: { children: ReactNode }) {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  if (!user.onboardingComplete) redirect("/onboarding");

  const [business] = await db.select().from(businesses).where(eq(businesses.userId, user.id)).limit(1);

  return (
    <AppShell
      user={{
        fullName: user.fullName,
        email: user.email,
        businessName: business?.name ?? "Your business",
        currency: business?.currency ?? "USD",
        isDemo: business?.isDemo ?? false,
      }}
    >
      {children}
    </AppShell>
  );
}
