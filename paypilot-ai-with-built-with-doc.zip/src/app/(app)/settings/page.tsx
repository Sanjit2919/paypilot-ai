import { SettingsView } from "@/components/analytics";

export default function SettingsPage() {
  return <SettingsView />;
}
