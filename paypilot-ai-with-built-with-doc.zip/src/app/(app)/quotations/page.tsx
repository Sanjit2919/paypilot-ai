import { QuotationsView } from "@/components/documents";

export default function QuotationsPage() {
  return <QuotationsView />;
}
