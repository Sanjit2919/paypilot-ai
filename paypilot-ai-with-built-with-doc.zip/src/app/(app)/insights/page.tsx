import { InsightsView } from "@/components/analytics";

export default function InsightsPage() {
  return <InsightsView />;
}
