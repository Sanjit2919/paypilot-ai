import { ExpensesView } from "@/components/records";

export default function ExpensesPage() {
  return <ExpensesView />;
}
