import { CashFlowView } from "@/components/analytics";

export default function CashFlowPage() {
  return <CashFlowView />;
}
