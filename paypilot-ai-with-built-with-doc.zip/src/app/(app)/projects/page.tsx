import { ProjectsView } from "@/components/records";

export default function ProjectsPage() {
  return <ProjectsView />;
}
