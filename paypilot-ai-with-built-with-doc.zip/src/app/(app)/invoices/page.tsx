import { InvoicesView } from "@/components/documents";

export default function InvoicesPage() {
  return <InvoicesView />;
}
