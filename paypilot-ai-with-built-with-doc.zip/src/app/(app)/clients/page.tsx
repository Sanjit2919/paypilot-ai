import { ClientsView } from "@/components/records";

export default function ClientsPage() {
  return <ClientsView />;
}
