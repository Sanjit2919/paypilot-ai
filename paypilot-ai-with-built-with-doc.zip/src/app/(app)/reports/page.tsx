import { ReportsView } from "@/components/analytics";

export default function ReportsPage() {
  return <ReportsView />;
}
