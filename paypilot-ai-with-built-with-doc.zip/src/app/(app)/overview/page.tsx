import { DashboardView } from "@/components/DashboardView";

export default function OverviewPage() {
  return <DashboardView />;
}
