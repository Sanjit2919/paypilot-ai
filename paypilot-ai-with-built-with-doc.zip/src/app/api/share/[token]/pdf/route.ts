import { getSharedInvoice } from "@/lib/share";
import { renderInvoicePdf } from "@/lib/pdf";

type Context = { params: Promise<{ token: string }> };

export async function GET(_request: Request, { params }: Context) {
  const { token } = await params;
  const shared = await getSharedInvoice(token);
  if (!shared) return Response.json({ error: "Invoice link not found or revoked." }, { status: 404 });
  const pdf = await renderInvoicePdf({
    business: shared.business,
    invoice: shared.invoice,
    clientEmail: shared.clientEmail,
    clientAddress: shared.clientAddress,
  });
  return new Response(Buffer.from(pdf), {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `attachment; filename="${shared.invoice.number}.pdf"`,
      "Cache-Control": "private, no-store",
      "X-Content-Type-Options": "nosniff",
    },
  });
}
