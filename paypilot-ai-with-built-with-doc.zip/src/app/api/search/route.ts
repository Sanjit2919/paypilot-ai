import { authed, fail, ok } from "@/lib/api";
import { loadLedger, toInvoiceDTO } from "@/lib/finance";
import { formatMoney } from "@/lib/format";

export type SearchResult = { id: string; kind: "client" | "project" | "invoice" | "quotation"; title: string; detail: string; href: string };

export async function GET(request: Request) {
  const auth = await authed();
  if (!auth.user) return auth.response;
  const query = (new URL(request.url).searchParams.get("q") ?? "").trim().toLowerCase().slice(0, 80);
  if (query.length < 2) return ok({ results: [] as SearchResult[] });

  const ledger = await loadLedger(auth.user.id);
  if (!ledger) return fail("Business profile not found", 404);
  const matches = (...parts: (string | null | undefined)[]) => parts.some((part) => part?.toLowerCase().includes(query));
  const results: SearchResult[] = [];

  for (const client of ledger.clients) {
    if (!matches(client.name, client.company, client.email)) continue;
    results.push({ id: client.id, kind: "client", title: client.name, detail: client.company || client.email || "Client", href: `/clients?highlight=${client.id}` });
    if (results.filter((r) => r.kind === "client").length >= 4) break;
  }
  for (const project of ledger.projects) {
    if (!matches(project.name, project.description)) continue;
    results.push({ id: project.id, kind: "project", title: project.name, detail: "Project", href: `/projects?highlight=${project.id}` });
    if (results.filter((r) => r.kind === "project").length >= 4) break;
  }
  for (const invoice of ledger.invoices) {
    const client = ledger.clients.find((c) => c.id === invoice.clientId);
    if (!matches(invoice.number, client?.name, client?.company)) continue;
    const dto = toInvoiceDTO(ledger, invoice);
    results.push({
      id: invoice.id,
      kind: "invoice",
      title: invoice.number,
      detail: `${dto.clientName} · ${formatMoney(dto.balance, ledger.business.currency)} due`,
      href: `/invoices?highlight=${invoice.id}`,
    });
    if (results.filter((r) => r.kind === "invoice").length >= 4) break;
  }
  for (const quote of ledger.quotations) {
    const client = ledger.clients.find((c) => c.id === quote.clientId);
    if (!matches(quote.number, client?.name, client?.company)) continue;
    results.push({ id: quote.id, kind: "quotation", title: quote.number, detail: `${client?.name || "Client"} · Quotation`, href: `/quotations?highlight=${quote.id}` });
    if (results.filter((r) => r.kind === "quotation").length >= 3) break;
  }
  return ok({ results: results.slice(0, 14) });
}
