import { randomBytes } from "node:crypto";
import { NextResponse } from "next/server";
import { and, eq, gt, isNull } from "drizzle-orm";
import { db } from "@/db";
import { businesses, passwordResets, users } from "@/db/schema";
import { createSession, destroySession, getSessionUser, hashPassword, verifyPassword } from "@/lib/auth";
import { fail, ok, readJson, str } from "@/lib/api";
import { seedDemoData } from "@/lib/seed";
import { rateLimit, requestIp } from "@/lib/security";

type Ctx = { params: Promise<{ action: string }> };

export async function GET(_request: Request, { params }: Ctx) {
  const { action } = await params;

  if (action === "demo") {
    const existingSession = await getSessionUser();
    if (existingSession) {
      return new NextResponse(null, { status: 307, headers: { Location: existingSession.onboardingComplete ? "/overview" : "/onboarding" } });
    }

    // Each visitor gets an isolated, disposable demo ledger rather than access to a shared account.
    const email = `demo-${randomBytes(12).toString("hex")}@paypilot.local`;
    const [user] = await db
      .insert(users)
      .values({
        email,
        passwordHash: hashPassword(randomBytes(24).toString("hex")),
        fullName: "Demo Owner",
      })
      .returning();

    await db.insert(businesses).values({
      userId: user.id,
      email: "hello@northwindstudio.example",
      name: "Northwind Studio",
      businessType: "Digital agency",
      industry: "Technology",
      currency: "USD",
      monthlyRevenueEstimate: "20000",
      country: "United States",
      onboardingComplete: true,
      isDemo: true,
    });
    await seedDemoData(user.id);
    await createSession(user.id);
    return new NextResponse(null, { status: 307, headers: { Location: "/overview" } });
  }

  if (action !== "session") return fail("Not found", 404);
  const user = await getSessionUser();
  if (!user) return ok({ user: null });
  return ok({ user });
}

export async function POST(request: Request, { params }: Ctx) {
  const { action } = await params;
  if (["login", "register", "forgot-password", "reset-password"].includes(action)) {
    const limited = rateLimit(`${requestIp(request)}:auth:${action}`, 12);
    if (!limited.allowed) return fail("Too many authentication attempts. Please wait before retrying.", 429, { retryAfterSeconds: limited.retryAfter });
  }
  const body = await readJson(request);

  if (action === "register") {
    const email = str(body.email).toLowerCase();
    const password = str(body.password);
    const fullName = str(body.fullName);
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return fail("Enter a valid email address.");
    if (password.length < 8) return fail("Password must be at least 8 characters.");

    const [existing] = await db.select({ id: users.id }).from(users).where(eq(users.email, email)).limit(1);
    if (existing) return fail("An account with this email already exists.", 409);

    const [user] = await db
      .insert(users)
      .values({ email, passwordHash: hashPassword(password), fullName })
      .returning();

    await db.insert(businesses).values({
      userId: user.id,
      email,
      name: fullName ? `${fullName}'s Business` : "",
      onboardingComplete: false,
    });

    await createSession(user.id);
    return ok({ user: { id: user.id, email: user.email, fullName: user.fullName }, onboarding: true });
  }

  if (action === "login") {
    const email = str(body.email).toLowerCase();
    const password = str(body.password);
    if (!email || !password) return fail("Email and password are required.");
    const [user] = await db.select().from(users).where(eq(users.email, email)).limit(1);
    if (!user || !verifyPassword(password, user.passwordHash)) {
      return fail("Invalid email or password.", 401);
    }
    const [business] = await db.select().from(businesses).where(eq(businesses.userId, user.id)).limit(1);
    await createSession(user.id);
    return ok({
      user: { id: user.id, email: user.email, fullName: user.fullName },
      onboarding: !(business?.onboardingComplete ?? false),
    });
  }

  if (action === "logout") {
    await destroySession();
    return ok({ ok: true });
  }

  if (action === "forgot-password") {
    const email = str(body.email).toLowerCase();
    if (!email) return fail("Email is required.");
    const [user] = await db.select().from(users).where(eq(users.email, email)).limit(1);
    if (!user) {
      // Do not disclose whether the account exists.
      return ok({ message: "If an account exists for that email, a reset link has been generated." });
    }
    const token = randomBytes(24).toString("hex");
    const expiresAt = new Date(Date.now() + 60 * 60 * 1000);
    await db.insert(passwordResets).values({ token, userId: user.id, expiresAt });
    return ok({
      message: "Reset link generated. In this environment email delivery is not configured, so use the link below.",
      resetPath: `/forgot-password?token=${token}`,
    });
  }

  if (action === "reset-password") {
    const token = str(body.token);
    const password = str(body.password);
    if (!token || password.length < 8) return fail("A valid token and 8+ character password are required.");
    const [reset] = await db
      .select()
      .from(passwordResets)
      .where(and(eq(passwordResets.token, token), gt(passwordResets.expiresAt, new Date()), isNull(passwordResets.usedAt)))
      .limit(1);
    if (!reset) return fail("This reset link is invalid or has expired.", 400);
    await db.update(users).set({ passwordHash: hashPassword(password) }).where(eq(users.id, reset.userId));
    await db.update(passwordResets).set({ usedAt: new Date() }).where(eq(passwordResets.token, token));
    return ok({ message: "Password updated. You can now sign in." });
  }

  return fail("Unknown action", 404);
}
