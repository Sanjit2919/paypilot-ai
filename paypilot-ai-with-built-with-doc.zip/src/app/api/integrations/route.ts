import { authed, ok } from "@/lib/api";
import { aiConfigured } from "@/lib/ai";
import { paypalConfigured, paypalConfig } from "@/lib/paypal";

export async function GET() {
  const auth = await authed();
  if (!auth.user) return auth.response;
  const config = paypalConfig();
  return ok({
    paypal: { configured: paypalConfigured(), mode: config?.mode ?? "demo" },
    gemini: { configured: aiConfigured(), model: "gemini-2.0-flash" },
  });
}
