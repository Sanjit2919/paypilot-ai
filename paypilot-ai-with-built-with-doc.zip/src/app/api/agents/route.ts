import { db } from "@/db";
import { agentActivities, cashFlowForecasts, notifications } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { authed, fail, ok } from "@/lib/api";
import { AGENTS, buildOrchestratorPlan } from "@/lib/agents";
import {
  buildForecast,
  computeHealth,
  computeMetrics,
  deriveActivities,
  generateInsights,
  loadLedger,
  logActivity,
  persistInsights,
} from "@/lib/finance";

export async function GET() {
  const auth = await authed();
  if (!auth.user) return auth.response;
  const ledger = await loadLedger(auth.user.id);
  if (!ledger) return fail("Complete onboarding first.", 404, { code: "no_business" });

  const metrics = computeMetrics(ledger);
  const forecast = buildForecast(ledger, metrics, 30);
  const plan = buildOrchestratorPlan(ledger);
  const recent = await db.select().from(agentActivities).where(eq(agentActivities.userId, auth.user.id)).orderBy(desc(agentActivities.createdAt)).limit(8);
  return ok({
    agents: AGENTS,
    plan,
    activities: recent.length ? recent.map((row) => ({ id: row.id, agent: row.agent, action: row.action, status: row.status, detail: row.detail, createdAt: row.createdAt.toISOString() })) : deriveActivities(ledger, metrics, forecast),
    health: computeHealth(metrics, forecast),
  });
}

export async function POST() {
  const auth = await authed();
  if (!auth.user) return auth.response;
  const ledger = await loadLedger(auth.user.id);
  if (!ledger) return fail("Complete onboarding first.", 404, { code: "no_business" });

  const metrics = computeMetrics(ledger);
  const forecast = buildForecast(ledger, metrics, 30);
  const health = computeHealth(metrics, forecast);
  const plan = buildOrchestratorPlan(ledger);
  const drafts = generateInsights(ledger, metrics, forecast);
  await persistInsights(auth.user.id, drafts);
  const forecasts = [30, 60, 90].map((horizon) => buildForecast(ledger, metrics, horizon));
  await db.insert(cashFlowForecasts).values(forecasts.map((item) => ({
    userId: auth.user.id,
    horizonDays: item.horizonDays,
    startingBalance: item.startingBalance.toFixed(2),
    projectedBalance: item.projectedBalance.toFixed(2),
    assumptions: item.assumptions,
    series: item.series,
  })));

  await logActivity(
    auth.user.id,
    "coordinator",
    "Orchestrated a full multi-agent financial review",
    "success",
    `Agents reviewed ${ledger.invoices.length} invoices, ${ledger.expenses.length} expenses and ${ledger.clients.length} clients. Health score ${health.score}/100.`,
    { agents: plan.agentsInvolved },
  );
  await logActivity(
    auth.user.id,
    "cashflow",
    `Produced 30/60/90-day cash-flow forecasts`,
    forecast.shortageDate ? "warning" : "success",
    forecast.shortageDate
      ? `Shortage risk detected around ${forecast.shortageDate} (estimate).`
      : `No shortage detected in the next 30 days (estimate).`,
    { horizon: 30, projected: forecast.projectedBalance },
  );
  await logActivity(
    auth.user.id,
    "payment",
    "Prepared collection follow-ups for approval",
    metrics.overdueCount ? "pending_approval" : "success",
    `${metrics.overdueCount} overdue invoice(s) worth ${metrics.overdueAmount.toFixed(2)} require a decision.`,
    { requiresApproval: true },
  );
  await logActivity(
    auth.user.id,
    "expense",
    "Completed expense anomaly review",
    "info",
    `Spend this month ${metrics.expenseThisMonth.toFixed(2)} vs last month ${metrics.expenseLastMonth.toFixed(2)}.`,
    {},
  );
  await logActivity(
    auth.user.id,
    "bi",
    "Published business intelligence brief",
    "info",
    plan.whatHappened,
    { healthScore: health.score },
  );

  const critical = drafts.filter((d) => d.severity === "critical" || d.severity === "high").slice(0, 3);
  if (critical.length) {
    await db.insert(notifications).values(
      critical.map((d) => ({
        userId: auth.user.id,
        title: d.title,
        body: d.explanation,
        type: d.severity === "critical" ? "critical" : "warning",
      })),
    );
  }

  return ok({
    plan,
    health,
    insights: drafts,
    activities: deriveActivities(ledger, metrics, forecast),
    agents: AGENTS,
  });
}
