import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { chatMessages, invoices, notifications, quotations } from "@/db/schema";
import { authed, fail, num, ok, readJson, str } from "@/lib/api";
import { createResource } from "@/lib/crud";
import { loadLedger, logActivity, nextDocumentNumber, round2, toInvoiceDTO } from "@/lib/finance";

export async function POST(request: Request) {
  const auth = await authed();
  if (!auth.user) return auth.response;
  const body = await readJson(request);
  const actionId = str(body.actionId);
  const messageId = str(body.messageId);
  if (!actionId || !messageId) return fail("An issued action and message are required.");

  const [message] = await db.select().from(chatMessages)
    .where(and(eq(chatMessages.id, messageId), eq(chatMessages.userId, auth.user.id), eq(chatMessages.role, "assistant")))
    .limit(1);
  const issuedAction = message?.actions.find((action) => action.id === actionId);
  if (!message || !issuedAction) return fail("This action was not issued or has already been approved.", 409);
  const payload = issuedAction.payload;
  const finish = async (result: Record<string, unknown>) => {
    await db.update(chatMessages)
      .set({ actions: message.actions.filter((action) => action.id !== actionId) })
      .where(and(eq(chatMessages.id, messageId), eq(chatMessages.userId, auth.user.id)));
    return ok(result);
  };

  const ledger = await loadLedger(auth.user.id);
  if (!ledger) return fail("Complete onboarding first.", 404, { code: "no_business" });

  if (actionId === "create_invoice") {
    const clientId = str(payload.clientId);
    const description = str(payload.description) || "Professional services";
    const amount = round2(num(payload.amount, 0));
    if (!clientId) return fail("A client is required to create an invoice.");
    if (amount <= 0) return fail("Invoice amount must be greater than zero.");
    const result = await createResource(auth.user.id, "invoices", {
      clientId,
      description,
      items: [{ description, quantity: 1, unitPrice: amount }],
      taxRate: num(payload.taxRate, num(ledger.business.taxRate)),
      status: "draft",
      notes: "Draft created by the Invoice Agent. Review before sending.",
    });
    const invoice = (result as { invoice?: { id: string; number: string } }).invoice;
    await logActivity(
      auth.user.id,
      "invoice",
      `Created draft invoice ${invoice?.number ?? ""} after owner approval`,
      "success",
      "Invoice Agent prepared the document; nothing was sent to the client.",
      { invoiceId: invoice?.id },
    );
    return finish({
      message: `Draft invoice ${invoice?.number ?? ""} created. Review it in Invoices before sending.`,
      invoiceId: invoice?.id,
    });
  }

  if (actionId === "send_reminders") {
    const invoiceIds = Array.isArray(payload.invoiceIds) ? payload.invoiceIds.map(String) : [];
    if (!invoiceIds.length) return fail("No invoices selected for reminders.");
    const targets = ledger.invoices.filter((invoice) => {
      if (!invoiceIds.includes(invoice.id) || invoice.dueDate >= new Date().toISOString().slice(0, 10)) return false;
      if (["draft", "void"].includes(invoice.status)) return false;
      const paid = ledger.payments.filter((payment) => payment.invoiceId === invoice.id && payment.status === "completed")
        .reduce((sum, payment) => sum + Number(payment.amount), 0);
      return Number(invoice.total) - paid > 0.01;
    });
    if (!targets.length) return fail("These invoices are no longer overdue or unpaid.", 409);
    await db.insert(notifications).values(
      targets.map((invoice) => ({
        userId: auth.user.id,
        title: `Follow-up draft ready · ${invoice.number}`,
        body: `Payment Agent prepared a follow-up for ${invoice.number}. No email was sent. Connect an email provider to deliver it.`,
        type: "info",
      })),
    );
    await logActivity(
      auth.user.id,
      "payment",
      `Prepared ${targets.length} payment follow-up draft(s)`,
      "success",
      "Follow-up drafts are saved as notifications. No external message was sent.",
      { invoiceIds },
    );
    return finish({
      message: `${targets.length} follow-up draft(s) saved. No email was sent; connect an email provider to deliver them.`,
    });
  }

  if (actionId === "convert_quotation") {
    const quotationId = str(payload.quotationId);
    const [quotation] = await db
      .select()
      .from(quotations)
      .where(and(eq(quotations.id, quotationId), eq(quotations.userId, auth.user.id)))
      .limit(1);
    if (!quotation) return fail("Quotation not found", 404);
    if (quotation.status === "converted") return fail("This quotation has already been converted.");
    const result = await createResource(auth.user.id, "invoices", {
      clientId: quotation.clientId ?? "",
      projectId: quotation.projectId ?? "",
      quotationId: quotation.id,
      items: ledger.quotations.find((q) => q.id === quotation.id)?.items ?? [],
      discountType: quotation.discountType,
      discountValue: num(quotation.discountValue),
      taxRate: num(quotation.taxRate),
      status: "sent",
      notes: `Converted from quotation ${quotation.number}.`,
    });
    const invoice = (result as { invoice?: { id: string; number: string } }).invoice;
    await logActivity(
      auth.user.id,
      "invoice",
      `Converted quotation ${quotation.number} into invoice ${invoice?.number ?? ""}`,
      "success",
      "Line items, discount and tax were carried over automatically.",
      { invoiceId: invoice?.id },
    );
    return finish({
      message: `Quotation ${quotation.number} converted into invoice ${invoice?.number ?? ""}.`,
      invoiceId: invoice?.id,
    });
  }

  if (actionId === "generate_report") {
    const type = str(payload.reportType) || "profit-loss";
    await logActivity(auth.user.id, "bi", `Generated the ${type} report`, "success", "Report is ready to download.", { type });
    return finish({ message: `Your ${type} report is ready on the Reports page.`, reportType: type });
  }

  if (actionId === "update_invoice_status") {
    const invoiceId = str(payload.invoiceId);
    const status = str(payload.status);
    if (!invoiceId || !status) return fail("Invoice and status are required.");
    await db
      .update(invoices)
      .set({ status })
      .where(and(eq(invoices.id, invoiceId), eq(invoices.userId, auth.user.id)));
    const fresh = await loadLedger(auth.user.id);
    const row = fresh?.invoices.find((i) => i.id === invoiceId);
    return finish({
      message: `Invoice ${row?.number ?? ""} marked as ${status}.`,
      invoice: fresh && row ? toInvoiceDTO(fresh, row) : null,
    });
  }

  if (actionId === "create_expense") {
    const result = await createResource(auth.user.id, "expenses", payload);
    const expense = (result as { expense?: { id: string } }).expense;
    await logActivity(auth.user.id, "expense", "Recorded an expense after owner approval", "success", "Expense Intelligence Agent will re-analyse spend.", {
      expenseId: expense?.id,
    });
    return finish({ message: "Expense recorded and queued for analysis." });
  }

  return fail("Unknown action", 400);
}

export async function GET() {
  const auth = await authed();
  if (!auth.user) return auth.response;
  const [row] = await db
    .select({ number: invoices.number })
    .from(invoices)
    .where(eq(invoices.userId, auth.user.id))
    .limit(1);
  const next = await nextDocumentNumber(auth.user.id, "invoice");
  return ok({ nextNumber: next, sample: row?.number ?? null });
}
