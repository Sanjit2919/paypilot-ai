import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { chatMessages } from "@/db/schema";
import { authed, fail, ok, readJson, str } from "@/lib/api";
import { buildAssistantReply, polishWithGemini } from "@/lib/agents";
import { loadLedger, logActivity } from "@/lib/finance";
import type { AgentActionCard } from "@/lib/types";
import { rateLimit, requestIp } from "@/lib/security";

export async function GET() {
  const auth = await authed();
  if (!auth.user) return auth.response;
  const rows = await db
    .select()
    .from(chatMessages)
    .where(eq(chatMessages.userId, auth.user.id))
    .orderBy(asc(chatMessages.createdAt))
    .limit(60);
  return ok({
    messages: rows.map((row) => ({
      id: row.id,
      role: row.role,
      content: row.content,
      agents: row.agents ?? [],
      actions: (row.actions ?? []) as AgentActionCard[],
      createdAt: row.createdAt.toISOString(),
    })),
  });
}

export async function POST(request: Request) {
  const auth = await authed();
  if (!auth.user) return auth.response;
  const body = await readJson(request);
  const limited = rateLimit(`${auth.user.id}:assistant:${requestIp(request)}`, 20);
  if (!limited.allowed) return fail("The assistant is receiving too many requests. Please wait a minute.", 429, { retryAfterSeconds: limited.retryAfter });
  const message = str(body.message).slice(0, 1200);
  if (!message) return fail("Ask a question to continue.");

  const ledger = await loadLedger(auth.user.id);
  if (!ledger) return fail("Complete onboarding first.", 404, { code: "no_business" });

  const base = buildAssistantReply(ledger, message);
  const reply = await polishWithGemini(ledger, message, base);

  const [userMessage] = await db
    .insert(chatMessages)
    .values({ userId: auth.user.id, role: "user", content: message, agents: [], actions: [] })
    .returning();
  const [assistantMessage] = await db
    .insert(chatMessages)
    .values({
      userId: auth.user.id,
      role: "assistant",
      content: reply.reply,
      agents: reply.agents,
      actions: reply.actions,
    })
    .returning();

  await logActivity(
    auth.user.id,
    "coordinator",
    "Handled an owner request via the AI Finance Assistant",
    reply.actions.length ? "pending_approval" : "success",
    reply.actions.length
      ? `Prepared ${reply.actions.length} action(s) awaiting explicit approval.`
      : "Answered using live business data.",
    { agents: reply.agents },
  );

  return ok({
    reply: {
      id: assistantMessage.id,
      role: "assistant",
      content: reply.reply,
      agents: reply.agents,
      actions: reply.actions,
      createdAt: assistantMessage.createdAt.toISOString(),
    },
    userMessage: {
      id: userMessage.id,
      role: "user",
      content: message,
      agents: [],
      actions: [],
      createdAt: userMessage.createdAt.toISOString(),
    },
  });
}
