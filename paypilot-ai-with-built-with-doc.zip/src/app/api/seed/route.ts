import { authed, fail, ok } from "@/lib/api";
import { seedDemoData } from "@/lib/seed";

export async function POST() {
  const auth = await authed();
  if (!auth.user) return auth.response;
  try {
    await seedDemoData(auth.user.id);
    return ok({ ok: true, message: "Demo workspace loaded with sample clients, projects, invoices and expenses." });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unable to load demo data.";
    return fail(message, 500);
  }
}
