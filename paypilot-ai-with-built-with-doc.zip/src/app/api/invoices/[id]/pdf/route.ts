import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { clients, invoices } from "@/db/schema";
import { authed, fail } from "@/lib/api";
import { loadLedger, toInvoiceDTO } from "@/lib/finance";
import { renderInvoicePdf } from "@/lib/pdf";

type Ctx = { params: Promise<{ id: string }> };

export async function GET(_request: Request, { params }: Ctx) {
  const auth = await authed();
  if (!auth.user) return auth.response;
  const { id } = await params;

  const [invoice] = await db
    .select()
    .from(invoices)
    .where(and(eq(invoices.id, id), eq(invoices.userId, auth.user.id)))
    .limit(1);
  if (!invoice) return fail("Invoice not found", 404);

  const ledger = await loadLedger(auth.user.id);
  if (!ledger) return fail("Business profile not found", 404);

  const [client] = invoice.clientId
    ? await db.select().from(clients).where(eq(clients.id, invoice.clientId)).limit(1)
    : [];

  const dto = toInvoiceDTO(ledger, ledger.invoices.find((i) => i.id === id)!);
  const pdf = await renderInvoicePdf({
    business: {
      id: ledger.business.id,
      name: ledger.business.name,
      businessType: ledger.business.businessType,
      industry: ledger.business.industry,
      currency: ledger.business.currency,
      monthlyRevenueEstimate: 0,
      email: ledger.business.email,
      country: ledger.business.country,
      taxRate: 0,
      paymentTermsDays: ledger.business.paymentTermsDays,
      cashBalance: 0,
      onboardingComplete: true,
      isDemo: ledger.business.isDemo,
    },
    invoice: dto,
    clientEmail: client?.email,
    clientAddress: client?.address,
  });

  return new Response(Buffer.from(pdf), {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `attachment; filename="${dto.number}.pdf"`,
      "Cache-Control": "no-store",
    },
  });
}
