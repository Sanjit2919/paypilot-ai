import { randomBytes } from "node:crypto";
import { and, eq, isNull } from "drizzle-orm";
import { db } from "@/db";
import { invoices } from "@/db/schema";
import { authed, fail, ok, publicOrigin } from "@/lib/api";

type Context = { params: Promise<{ id: string }> };

export async function POST(request: Request, { params }: Context) {
  const auth = await authed();
  if (!auth.user) return auth.response;
  const { id } = await params;
  const [invoice] = await db.select({ id: invoices.id, shareToken: invoices.shareToken })
    .from(invoices).where(and(eq(invoices.id, id), eq(invoices.userId, auth.user.id))).limit(1);
  if (!invoice) return fail("Invoice not found.", 404);

  let token = invoice.shareToken;
  if (!token) {
    const created = await db.update(invoices)
      .set({ shareToken: randomBytes(32).toString("base64url") })
      .where(and(eq(invoices.id, id), eq(invoices.userId, auth.user.id), isNull(invoices.shareToken)))
      .returning({ shareToken: invoices.shareToken });
    token = created[0]?.shareToken ?? null;
    if (!token) {
      const [latest] = await db.select({ shareToken: invoices.shareToken }).from(invoices)
        .where(and(eq(invoices.id, id), eq(invoices.userId, auth.user.id))).limit(1);
      token = latest?.shareToken ?? null;
    }
  }
  if (!token) return fail("Could not create a secure link. Please retry.", 500);
  return ok({ url: `${publicOrigin(request)}/view/${token}`, message: "Secure invoice link ready. Anyone with this link can view this invoice only." });
}

export async function DELETE(_request: Request, { params }: Context) {
  const auth = await authed();
  if (!auth.user) return auth.response;
  const { id } = await params;
  const updated = await db.update(invoices).set({ shareToken: null })
    .where(and(eq(invoices.id, id), eq(invoices.userId, auth.user.id))).returning({ id: invoices.id });
  if (!updated.length) return fail("Invoice not found.", 404);
  return ok({ ok: true, message: "Invoice link revoked. The old URL no longer works." });
}
