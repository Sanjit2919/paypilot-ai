import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { financialActions } from "@/db/schema";
import { authed, fail, ok, readJson, str, today } from "@/lib/api";
import { createResource } from "@/lib/crud";
import { buildForecast, computeMetrics, loadLedger, logActivity, toInvoiceDTO } from "@/lib/finance";
import { formatDate, formatMoney } from "@/lib/format";
import { notify } from "@/lib/notifications";
import { isUuid, rateLimit, requestIp } from "@/lib/security";

function dto(row: typeof financialActions.$inferSelect) {
  return {
    id: row.id,
    agent: row.agent,
    kind: row.kind,
    title: row.title,
    reason: row.reason,
    expectedOutcome: row.expectedOutcome,
    supportingData: row.supportingData,
    approvalStatus: row.approvalStatus,
    executionStatus: row.executionStatus,
    resultMessage: row.resultMessage,
    approvedAt: row.approvedAt?.toISOString() ?? null,
    executedAt: row.executedAt?.toISOString() ?? null,
    createdAt: row.createdAt.toISOString(),
  };
}

async function listActions(userId: string) {
  const rows = await db.select().from(financialActions).where(eq(financialActions.userId, userId)).orderBy(desc(financialActions.createdAt)).limit(30);
  return rows.map(dto);
}

/** Deterministic agent recommendations, deduplicated by source document/date. */
async function syncRecommendations(userId: string) {
  const ledger = await loadLedger(userId);
  if (!ledger) return;
  const existing = await db.select({ dedupeKey: financialActions.dedupeKey }).from(financialActions).where(eq(financialActions.userId, userId));
  const keys = new Set(existing.map((row) => row.dedupeKey));
  const values: (typeof financialActions.$inferInsert)[] = [];

  const open = ledger.invoices.map((row) => toInvoiceDTO(ledger, row)).filter((invoice) => invoice.balance > 0.01 && invoice.status !== "draft" && invoice.status !== "void");
  const overdue = open.filter((invoice) => invoice.dueDate < today()).sort((a, b) => a.dueDate.localeCompare(b.dueDate))[0];
  if (overdue) {
    const key = `reminder:${overdue.id}:${overdue.dueDate}`;
    const client = ledger.clients.find((item) => item.id === overdue.clientId);
    const balance = formatMoney(overdue.balance, ledger.business.currency);
    if (!keys.has(key)) values.push({
      userId,
      dedupeKey: key,
      agent: "payment",
      kind: "payment_reminder",
      title: `Follow up on ${overdue.number} with ${overdue.clientName}`,
      reason: `${overdue.number} was due ${formatDate(overdue.dueDate)} and ${balance} remains unpaid. ${client?.name ?? "This client"} should be contacted before newer invoices.`,
      expectedOutcome: "A professional reminder is prepared for your review, giving the client the invoice number, amount and due date. No external email is sent without a configured provider.",
      supportingData: {
        invoiceId: overdue.id,
        invoiceNumber: overdue.number,
        clientName: overdue.clientName,
        balance: overdue.balance,
        dueDate: overdue.dueDate,
        reminderText: `Subject: Friendly reminder for invoice ${overdue.number}\n\nHello ${overdue.clientName},\n\nThis is a friendly reminder that invoice ${overdue.number} for ${balance} was due on ${formatDate(overdue.dueDate)}. Please let us know if payment has already been arranged or if you need any details from us.\n\nThank you,\n${ledger.business.name}`,
      },
    });
  }

  const quotation = ledger.quotations.find((item) => item.status === "accepted");
  if (quotation && !keys.has(`convert:${quotation.id}`)) values.push({
    userId,
    dedupeKey: `convert:${quotation.id}`,
    agent: "invoice",
    kind: "convert_quotation",
    title: `Convert ${quotation.number} into an invoice`,
    reason: `${quotation.number} is accepted and has not been converted. Its client, line items, tax and discount can be carried forward without retyping.`,
    expectedOutcome: "An invoice is created with the accepted quotation details and the quotation is marked converted.",
    supportingData: { quotationId: quotation.id, quotationNumber: quotation.number, total: Number(quotation.total) },
  });

  const metrics = computeMetrics(ledger);
  const forecast = buildForecast(ledger, metrics, 60);
  if (forecast.shortageDate && !keys.has(`cashflow:${forecast.shortageDate}`)) values.push({
    userId,
    dedupeKey: `cashflow:${forecast.shortageDate}`,
    agent: "cashflow",
    kind: "cashflow_alert",
    title: `Review cash-flow risk around ${formatDate(forecast.shortageDate)}`,
    reason: `The 60-day model projects a low balance of ${formatMoney(forecast.lowestBalance, ledger.business.currency)} on ${formatDate(forecast.lowestDate)}. This is an estimate, not a guaranteed outcome.`,
    expectedOutcome: "A cash-flow warning is added to Notifications with the projected date, balance and the assumptions to review.",
    supportingData: { shortageDate: forecast.shortageDate, lowestBalance: forecast.lowestBalance, assumptions: forecast.assumptions },
  });

  if (values.length) await db.insert(financialActions).values(values);
}

export async function GET() {
  const auth = await authed();
  if (!auth.user) return auth.response;
  await syncRecommendations(auth.user.id);
  return ok({ actions: await listActions(auth.user.id) });
}

export async function POST(request: Request) {
  const auth = await authed();
  if (!auth.user) return auth.response;
  const limited = rateLimit(`${auth.user.id}:actions:${requestIp(request)}`, 40);
  if (!limited.allowed) return fail("Too many action requests. Please wait before retrying.", 429);
  const body = await readJson(request);
  const id = str(body.id);
  const operation = str(body.operation);
  if (!isUuid(id) || !["approve", "execute", "dismiss"].includes(operation)) return fail("A valid action and operation are required.");

  const [action] = await db.select().from(financialActions).where(and(eq(financialActions.id, id), eq(financialActions.userId, auth.user.id))).limit(1);
  if (!action) return fail("Action not found.", 404);

  if (operation === "dismiss") {
    await db.update(financialActions).set({ approvalStatus: "dismissed", executionStatus: "skipped" }).where(eq(financialActions.id, id));
    await logActivity(auth.user.id, action.agent, `Dismissed recommendation: ${action.title}`, "info", "No action was executed.", { actionId: id });
    return ok({ action: (await listActions(auth.user.id)).find((item) => item.id === id) });
  }

  if (operation === "approve") {
    if (action.approvalStatus !== "pending") return fail("Only pending recommendations can be approved.", 409);
    await db.update(financialActions).set({ approvalStatus: "approved", executionStatus: "ready", approvedAt: new Date() }).where(eq(financialActions.id, id));
    await logActivity(auth.user.id, action.agent, `Approved action: ${action.title}`, "pending_approval", "Approved by the business owner; ready to execute.", { actionId: id });
    return ok({ action: (await listActions(auth.user.id)).find((item) => item.id === id), message: "Approved. The action is ready to execute." });
  }

  if (action.approvalStatus !== "approved" || action.executionStatus !== "ready") return fail("Approve this action before executing it.", 409);

  let resultMessage = "";
  if (action.kind === "payment_reminder") {
    const reminderText = str(action.supportingData.reminderText);
    await notify(auth.user.id, `Payment reminder draft · ${str(action.supportingData.invoiceNumber)}`, reminderText, "info");
    resultMessage = "Reminder draft saved to Notifications. No external email was sent because no email provider is configured.";
  } else if (action.kind === "convert_quotation") {
    const quotationId = str(action.supportingData.quotationId);
    const ledger = await loadLedger(auth.user.id);
    const quotation = ledger?.quotations.find((item) => item.id === quotationId);
    if (!ledger || !quotation) return fail("The quotation is no longer available.", 409);
    const result = await createResource(auth.user.id, "invoices", {
      quotationId,
      clientId: quotation.clientId ?? "",
      projectId: quotation.projectId ?? "",
      items: quotation.items,
      discountType: quotation.discountType,
      discountValue: Number(quotation.discountValue),
      taxRate: Number(quotation.taxRate),
      status: "sent",
      notes: `Converted from accepted quotation ${quotation.number}.`,
    }) as { invoice?: { id: string; number: string } } | Response;
    if (result instanceof Response) return result;
    resultMessage = `Invoice ${result.invoice?.number ?? "created"} was generated from ${quotation.number}.`;
  } else if (action.kind === "cashflow_alert") {
    await notify(auth.user.id, action.title, action.reason, "warning");
    resultMessage = "Cash-flow warning saved to Notifications. The forecast remains an estimate.";
  } else {
    return fail("This recommendation has no supported executor.", 400);
  }

  await db.update(financialActions).set({ executionStatus: "completed", resultMessage, executedAt: new Date() }).where(eq(financialActions.id, id));
  await logActivity(auth.user.id, action.agent, `Executed approved action: ${action.title}`, "success", resultMessage, { actionId: id, kind: action.kind });
  await notify(auth.user.id, "Approved action completed", resultMessage, "success");
  return ok({ action: (await listActions(auth.user.id)).find((item) => item.id === id), message: resultMessage });
}
