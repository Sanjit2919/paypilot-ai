import { authed, fail, ok } from "@/lib/api";
import { buildForecast, buildMonthly, computeMetrics, loadLedger } from "@/lib/finance";

export async function GET(request: Request) {
  const auth = await authed();
  if (!auth.user) return auth.response;
  const ledger = await loadLedger(auth.user.id);
  if (!ledger) return fail("Complete onboarding to load cash-flow analytics.", 404, { code: "no_business" });

  const url = new URL(request.url);
  const horizon = Number.parseInt(url.searchParams.get("horizon") ?? "30", 10);
  const safeHorizon = [7, 30, 60, 90].includes(horizon) ? horizon : 30;

  const metrics = computeMetrics(ledger);
  const forecast = buildForecast(ledger, metrics, safeHorizon);
  const forecast90 = safeHorizon === 90 ? forecast : buildForecast(ledger, metrics, 90);
  const forecast60 = safeHorizon === 60 ? forecast : buildForecast(ledger, metrics, 60);
  const forecast30 = safeHorizon === 30 ? forecast : buildForecast(ledger, metrics, 30);
  const forecast7 = safeHorizon === 7 ? forecast : buildForecast(ledger, metrics, 7);

  return ok({
    business: { currency: ledger.business.currency, name: ledger.business.name },
    metrics,
    forecast,
    forecast7,
    forecast30,
    forecast60,
    forecast90,
    monthly: buildMonthly(ledger),
  });
}
