import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { receiptAttachments } from "@/db/schema";
import { authed, fail } from "@/lib/api";
import { isUuid } from "@/lib/security";

type Context = { params: Promise<{ id: string }> };

export async function GET(_request: Request, { params }: Context) {
  const auth = await authed();
  if (!auth.user) return auth.response;
  const { id } = await params;
  if (!isUuid(id)) return fail("Receipt not found.", 404);
  const [receipt] = await db.select().from(receiptAttachments)
    .where(and(eq(receiptAttachments.id, id), eq(receiptAttachments.userId, auth.user.id))).limit(1);
  if (!receipt) return fail("Receipt not found.", 404);
  return new Response(Buffer.from(receipt.contentBase64, "base64"), {
    headers: {
      "Content-Type": receipt.mimeType,
      "Content-Disposition": `inline; filename="${receipt.fileName.replace(/"/g, "")}"`,
      "Cache-Control": "private, no-store",
      "X-Content-Type-Options": "nosniff",
    },
  });
}
