import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { expenses, receiptAttachments } from "@/db/schema";
import { authed, fail, ok, str } from "@/lib/api";
import { logActivity } from "@/lib/finance";
import { isUuid, rateLimit, requestIp } from "@/lib/security";

const ALLOWED = new Set(["image/png", "image/jpeg", "application/pdf"]);
const MAX_BYTES = 2 * 1024 * 1024;

export async function POST(request: Request) {
  const auth = await authed();
  if (!auth.user) return auth.response;
  const limited = rateLimit(`${auth.user.id}:receipt:${requestIp(request)}`, 20);
  if (!limited.allowed) return fail("Too many receipt uploads. Please wait before retrying.", 429);

  const form = await request.formData().catch(() => null);
  if (!form) return fail("Upload a valid receipt form.");
  const expenseId = str(form.get("expenseId"));
  const file = form.get("file");
  if (!isUuid(expenseId) || !(file instanceof File)) return fail("An expense and receipt file are required.");
  if (!ALLOWED.has(file.type)) return fail("Receipt must be a PNG, JPG or PDF file.");
  if (file.size <= 0 || file.size > MAX_BYTES) return fail("Receipt must be between 1 byte and 2 MB.");

  const [expense] = await db.select().from(expenses).where(and(eq(expenses.id, expenseId), eq(expenses.userId, auth.user.id))).limit(1);
  if (!expense) return fail("Expense not found.", 404);

  const bytes = Buffer.from(await file.arrayBuffer());
  const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, "_").slice(0, 120) || "receipt";
  const [receipt] = await db.insert(receiptAttachments).values({
    userId: auth.user.id,
    expenseId,
    fileName: safeName,
    mimeType: file.type,
    contentBase64: bytes.toString("base64"),
  }).returning({ id: receiptAttachments.id });
  const url = `/api/receipts/${receipt.id}`;
  await db.update(expenses).set({ receiptUrl: url }).where(and(eq(expenses.id, expenseId), eq(expenses.userId, auth.user.id)));
  await logActivity(auth.user.id, "expense", "Attached an expense receipt", "success", `${safeName} (${file.type}, ${file.size} bytes).`, { expenseId, receiptId: receipt.id });
  return ok({ receiptUrl: url, fileName: safeName }, 201);
}
