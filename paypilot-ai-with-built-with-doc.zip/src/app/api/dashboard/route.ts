import { authed, fail, ok } from "@/lib/api";
import { buildDashboard } from "@/lib/finance";

export async function GET() {
  const auth = await authed();
  if (!auth.user) return auth.response;
  const payload = await buildDashboard(auth.user.id);
  if (!payload) return fail("Complete onboarding to load your dashboard.", 404, { code: "no_business" });
  return ok(payload);
}
