import { authed, fail } from "@/lib/api";
import {
  buildClientProfiles,
  buildForecast,
  buildMonthly,
  computeMetrics,
  loadLedger,
  toBusinessDTO,
  toInvoiceDTO,
} from "@/lib/finance";
import { formatDate, titleCase } from "@/lib/format";
import { renderReportPdf } from "@/lib/pdf";

const TYPES = ["profit-loss", "expenses", "revenue", "outstanding", "clients", "cashflow"] as const;
type ReportType = (typeof TYPES)[number];

function csvEscape(value: string | number): string {
  const str = String(value);
  return /[",\n]/.test(str) ? `"${str.replace(/"/g, '""')}"` : str;
}

function toCsv(rows: (string | number)[][]): string {
  return rows.map((row) => row.map(csvEscape).join(",")).join("\n");
}

export async function GET(request: Request) {
  const auth = await authed();
  if (!auth.user) return auth.response;
  const ledger = await loadLedger(auth.user.id);
  if (!ledger) return fail("Complete onboarding first.", 404, { code: "no_business" });

  const url = new URL(request.url);
  const type = (url.searchParams.get("type") ?? "profit-loss") as ReportType;
  const format = url.searchParams.get("format") === "pdf" ? "pdf" : "csv";
  if (!TYPES.includes(type)) return fail("Unknown report type");

  const metrics = computeMetrics(ledger);
  const monthly = buildMonthly(ledger);
  const currency = ledger.business.currency;
  const period = `${monthly[0]?.label ?? ""} – ${monthly[monthly.length - 1]?.label ?? ""} ${new Date().getFullYear()}`;
  const business = toBusinessDTO(ledger.business);

  const rows: (string | number)[][] = [];
  const sections: { heading: string; rows: [string, string][] }[] = [];
  const notes: string[] = [];

  if (type === "profit-loss") {
    rows.push(["Month", "Revenue", "Expenses", "Net profit"]);
    for (const point of monthly) rows.push([point.label, point.revenue.toFixed(2), point.expenses.toFixed(2), point.profit.toFixed(2)]);
    rows.push(["Total", metrics.totalRevenue.toFixed(2), metrics.totalExpenses.toFixed(2), metrics.netProfit.toFixed(2)]);
    sections.push({
      heading: "Profit & loss summary",
      rows: [
        ["Total revenue", `${currency} ${metrics.totalRevenue.toFixed(2)}`],
        ["Total expenses", `${currency} ${metrics.totalExpenses.toFixed(2)}`],
        ["Net profit", `${currency} ${metrics.netProfit.toFixed(2)}`],
        ["Net margin", `${metrics.profitMargin.toFixed(1)}%`],
      ],
    });
    sections.push({
      heading: "Monthly breakdown",
      rows: monthly.map((p) => [p.label, `${p.revenue.toFixed(2)} / ${p.expenses.toFixed(2)} / ${p.profit.toFixed(2)}`]),
    });
    notes.push("Revenue is recognised when payments are marked completed. Expenses are recognised on their transaction date.");
  } else if (type === "expenses") {
    const totals = new Map<string, number>();
    for (const e of ledger.expenses) totals.set(e.category, (totals.get(e.category) ?? 0) + Number(e.amount));
    const sorted = [...totals.entries()].sort((a, b) => b[1] - a[1]);
    rows.push(["Category", "Amount", "Share %"]);
    for (const [category, amount] of sorted) {
      rows.push([titleCase(category), amount.toFixed(2), ((amount / (metrics.totalExpenses || 1)) * 100).toFixed(1)]);
    }
    sections.push({ heading: "Expense breakdown", rows: sorted.map(([c, a]) => [titleCase(c), `${currency} ${a.toFixed(2)}`]) });
    sections.push({
      heading: "Key figures",
      rows: [
        ["Total expenses", `${currency} ${metrics.totalExpenses.toFixed(2)}`],
        ["This month", `${currency} ${metrics.expenseThisMonth.toFixed(2)}`],
        ["Last month", `${currency} ${metrics.expenseLastMonth.toFixed(2)}`],
        ["Recurring monthly", `${currency} ${metrics.recurringMonthlyExpense.toFixed(2)}`],
      ],
    });
  } else if (type === "revenue") {
    const byClient = new Map<string, number>();
    for (const p of ledger.payments) {
      if (p.status !== "completed") continue;
      const name = ledger.clients.find((c) => c.id === p.clientId)?.name ?? "Unassigned";
      byClient.set(name, (byClient.get(name) ?? 0) + Number(p.amount));
    }
    const sorted = [...byClient.entries()].sort((a, b) => b[1] - a[1]);
    rows.push(["Client", "Collected revenue"]);
    for (const [client, amount] of sorted) rows.push([client, amount.toFixed(2)]);
    rows.push(["Total", metrics.totalRevenue.toFixed(2)]);
    sections.push({ heading: "Revenue by client", rows: sorted.map(([c, a]) => [c, `${currency} ${a.toFixed(2)}`]) });
    sections.push({
      heading: "Revenue trend",
      rows: monthly.map((p) => [p.label, `${currency} ${p.revenue.toFixed(2)}`]),
    });
  } else if (type === "outstanding") {
    const open = ledger.invoices.map((row) => toInvoiceDTO(ledger, row)).filter((i) => i.balance > 0.005);
    rows.push(["Invoice", "Client", "Issued", "Due", "Total", "Paid", "Balance", "Status"]);
    for (const inv of open) {
      rows.push([inv.number, inv.clientName, inv.issueDate, inv.dueDate, inv.total.toFixed(2), inv.amountPaid.toFixed(2), inv.balance.toFixed(2), inv.status]);
    }
    sections.push({
      heading: "Outstanding invoices",
      rows: [
        ["Open invoices", String(metrics.outstandingInvoices)],
        ["Outstanding amount", `${currency} ${metrics.outstandingAmount.toFixed(2)}`],
        ["Overdue amount", `${currency} ${metrics.overdueAmount.toFixed(2)}`],
        ["Overdue count", String(metrics.overdueCount)],
      ],
    });
    sections.push({ heading: "Invoice detail", rows: open.slice(0, 10).map((i) => [i.number, `${i.clientName} · ${i.balance.toFixed(2)} due ${formatDate(i.dueDate)}`]) });
  } else if (type === "clients") {
    const profiles = buildClientProfiles(ledger);
    rows.push(["Client", "Company", "Invoiced", "Paid", "Outstanding", "Overdue", "On-time %", "Risk"]);
    for (const p of profiles) {
      rows.push([p.name, p.company, p.invoiced.toFixed(2), p.paid.toFixed(2), p.outstanding.toFixed(2), p.overdue.toFixed(2), String(p.onTimeRate), p.riskLevel]);
    }
    sections.push({
      heading: "Client payment behaviour",
      rows: profiles.map((p) => [p.name, `${p.paid.toFixed(2)} paid · ${p.onTimeRate}% on-time · risk ${p.riskLevel}`]),
    });
  } else {
    const forecast = buildForecast(ledger, metrics, 90);
    rows.push(["Date", "Projected balance", "Expected inflow", "Expected outflow"]);
    for (const point of forecast.series) {
      rows.push([point.date, point.balance.toFixed(2), point.inflow.toFixed(2), point.outflow.toFixed(2)]);
    }
    sections.push({
      heading: "90-day cash-flow forecast (estimate)",
      rows: [
        ["Starting balance", `${currency} ${forecast.startingBalance.toFixed(2)}`],
        ["Projected balance", `${currency} ${forecast.projectedBalance.toFixed(2)}`],
        ["Lowest balance", `${currency} ${forecast.lowestBalance.toFixed(2)} on ${formatDate(forecast.lowestDate)}`],
        ["Expected inflow", `${currency} ${forecast.expectedInflow.toFixed(2)}`],
        ["Expected outflow", `${currency} ${forecast.expectedOutflow.toFixed(2)}`],
        ["Confidence", `${forecast.confidence}%`],
      ],
    });
    notes.push(...forecast.assumptions);
  }

  if (format === "csv") {
    const csv = toCsv(rows);
    return new Response(csv, {
      headers: {
        "Content-Type": "text/csv; charset=utf-8",
        "Content-Disposition": `attachment; filename="paypilot-${type}-${new Date().toISOString().slice(0, 10)}.csv"`,
        "Cache-Control": "no-store",
      },
    });
  }

  const pdf = await renderReportPdf({
    business,
    title: `${titleCase(type.replace("-", " "))} report`,
    period,
    sections,
    notes,
  });

  return new Response(Buffer.from(pdf), {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `attachment; filename="paypilot-${type}-${new Date().toISOString().slice(0, 10)}.pdf"`,
      "Cache-Control": "no-store",
    },
  });
}
