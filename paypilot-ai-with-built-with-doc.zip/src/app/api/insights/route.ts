import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { aiInsights } from "@/db/schema";
import { authed, fail, ok, readJson, str } from "@/lib/api";
import { buildForecast, computeMetrics, generateInsights, loadLedger, persistInsights } from "@/lib/finance";
import type { InsightDTO, Severity } from "@/lib/types";

export async function GET() {
  const auth = await authed();
  if (!auth.user) return auth.response;
  const ledger = await loadLedger(auth.user.id);
  if (!ledger) return fail("Complete onboarding first.", 404, { code: "no_business" });

  const metrics = computeMetrics(ledger);
  const forecast = buildForecast(ledger, metrics, 30);
  await persistInsights(auth.user.id, generateInsights(ledger, metrics, forecast));

  const rows = await db
    .select()
    .from(aiInsights)
    .where(eq(aiInsights.userId, auth.user.id))
    .orderBy(desc(aiInsights.createdAt));

  const insights: InsightDTO[] = rows.map((row) => ({
    id: row.id,
    agent: row.agent,
    severity: row.severity as Severity,
    title: row.title,
    explanation: row.explanation,
    supportingData: row.supportingData ?? {},
    recommendation: row.recommendation,
    status: row.status,
    createdAt: row.createdAt.toISOString(),
  }));

  return ok({ insights, generatedAt: new Date().toISOString() });
}

export async function PATCH(request: Request) {
  const auth = await authed();
  if (!auth.user) return auth.response;
  const body = await readJson(request);
  const id = str(body.id);
  const status = str(body.status);
  if (!id || !["open", "dismissed", "acted"].includes(status)) return fail("Invalid insight update.");
  await db
    .update(aiInsights)
    .set({ status })
    .where(and(eq(aiInsights.id, id), eq(aiInsights.userId, auth.user.id)));
  return ok({ ok: true });
}
