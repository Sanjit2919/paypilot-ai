import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { notifications } from "@/db/schema";
import { authed, ok, readJson, str } from "@/lib/api";

export async function GET() {
  const auth = await authed();
  if (!auth.user) return auth.response;
  const rows = await db
    .select()
    .from(notifications)
    .where(eq(notifications.userId, auth.user.id))
    .orderBy(desc(notifications.createdAt))
    .limit(30);
  return ok({
    notifications: rows.map((row) => ({
      id: row.id,
      title: row.title,
      body: row.body,
      type: row.type,
      read: row.read,
      createdAt: row.createdAt.toISOString(),
    })),
  });
}

export async function PATCH(request: Request) {
  const auth = await authed();
  if (!auth.user) return auth.response;
  const body = await readJson(request);
  const id = str(body.id);
  if (id) {
    await db
      .update(notifications)
      .set({ read: true })
      .where(and(eq(notifications.id, id), eq(notifications.userId, auth.user.id)));
  } else {
    await db.update(notifications).set({ read: true }).where(eq(notifications.userId, auth.user.id));
  }
  return ok({ ok: true });
}
