import { authed, fail, ok, readJson } from "@/lib/api";
import { deleteResource, isResource, updateResource } from "@/lib/crud";

type Ctx = { params: Promise<{ resource: string; id: string }> };

export async function PATCH(request: Request, { params }: Ctx) {
  const auth = await authed();
  if (!auth.user) return auth.response;
  const { resource, id } = await params;
  if (!isResource(resource)) return fail("Unknown resource", 404);
  const body = await readJson(request);
  try {
    const result = await updateResource(auth.user.id, resource, id, body);
    return result instanceof Response ? result : ok(result);
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unable to update record.";
    return fail(message, 400);
  }
}

export async function DELETE(_request: Request, { params }: Ctx) {
  const auth = await authed();
  if (!auth.user) return auth.response;
  const { resource, id } = await params;
  if (!isResource(resource)) return fail("Unknown resource", 404);
  try {
    const result = await deleteResource(auth.user.id, resource, id);
    return result instanceof Response ? result : ok(result);
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unable to delete record.";
    return fail(message, 400);
  }
}
