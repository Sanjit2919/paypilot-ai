import { authed, fail, ok, readJson } from "@/lib/api";
import { createResource, isResource, listResource } from "@/lib/crud";

type Ctx = { params: Promise<{ resource: string }> };

export async function GET(_request: Request, { params }: Ctx) {
  const auth = await authed();
  if (!auth.user) return auth.response;
  const { resource } = await params;
  if (!isResource(resource)) return fail("Unknown resource", 404);
  const result = await listResource(auth.user.id, resource);
  return result instanceof Response ? result : ok(result);
}

export async function POST(request: Request, { params }: Ctx) {
  const auth = await authed();
  if (!auth.user) return auth.response;
  const { resource } = await params;
  if (!isResource(resource)) return fail("Unknown resource", 404);
  const body = await readJson(request);
  try {
    const result = await createResource(auth.user.id, resource, body);
    return result instanceof Response ? result : ok(result, 201);
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unable to create record.";
    return fail(message, 400);
  }
}
