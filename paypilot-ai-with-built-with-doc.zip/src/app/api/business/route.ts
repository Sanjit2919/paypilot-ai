import { eq } from "drizzle-orm";
import { db } from "@/db";
import { businesses } from "@/db/schema";
import { authed, fail, num, ok, readJson, str } from "@/lib/api";
import { toBusinessDTO } from "@/lib/finance";
import { seedDemoData } from "@/lib/seed";

export async function GET() {
  const auth = await authed();
  if (!auth.user) return auth.response;
  const [business] = await db.select().from(businesses).where(eq(businesses.userId, auth.user.id)).limit(1);
  if (!business) return fail("Business profile not found", 404);
  return ok({ business: toBusinessDTO(business) });
}

export async function PATCH(request: Request) {
  const auth = await authed();
  if (!auth.user) return auth.response;
  const body = await readJson(request);
  const [business] = await db.select().from(businesses).where(eq(businesses.userId, auth.user.id)).limit(1);
  if (!business) return fail("Business profile not found", 404);

  const updates: Record<string, unknown> = {};
  if (body.name !== undefined) updates.name = str(body.name);
  if (body.businessType !== undefined) updates.businessType = str(body.businessType);
  if (body.industry !== undefined) updates.industry = str(body.industry);
  if (body.currency !== undefined) updates.currency = str(body.currency).toUpperCase().slice(0, 3);
  if (body.monthlyRevenueEstimate !== undefined) updates.monthlyRevenueEstimate = num(body.monthlyRevenueEstimate).toFixed(2);
  if (body.email !== undefined) updates.email = str(body.email);
  if (body.country !== undefined) updates.country = str(body.country);
  if (body.taxRate !== undefined) updates.taxRate = num(body.taxRate).toFixed(2);
  if (body.paymentTermsDays !== undefined) updates.paymentTermsDays = Math.max(0, Math.round(num(body.paymentTermsDays, 14)));
  if (body.cashBalance !== undefined) updates.cashBalance = num(body.cashBalance).toFixed(2);
  if (body.onboardingComplete !== undefined) updates.onboardingComplete = Boolean(body.onboardingComplete);

  if (body.onboardingComplete === true) {
    if (!updates.name && !business.name) return fail("Business name is required.");
    if (!updates.currency && !business.currency) return fail("Currency is required.");
  }

  if (Object.keys(updates).length) {
    await db.update(businesses).set(updates).where(eq(businesses.id, business.id));
  }

  if (body.seedDemo === true) {
    await seedDemoData(auth.user.id);
  }

  const [fresh] = await db.select().from(businesses).where(eq(businesses.id, business.id)).limit(1);
  return ok({ business: toBusinessDTO(fresh) });
}
