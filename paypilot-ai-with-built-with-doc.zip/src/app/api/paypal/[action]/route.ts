import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { invoices, payments } from "@/db/schema";
import { authed, fail, money, ok, publicOrigin, readJson, str, today } from "@/lib/api";
import { loadLedger, logActivity, round2, toInvoiceDTO } from "@/lib/finance";
import { capturePayPalOrder, createPayPalOrder, getPayPalOrderStatus, paypalConfig, paypalConfigured } from "@/lib/paypal";
import { notify } from "@/lib/notifications";
import { isUuid, rateLimit, requestIp } from "@/lib/security";

type Ctx = { params: Promise<{ action: string }> };

export async function GET() {
  const auth = await authed();
  if (!auth.user) return auth.response;
  return ok({ configured: paypalConfigured(), mode: paypalConfig()?.mode ?? "demo" });
}

export async function POST(request: Request, { params }: Ctx) {
  const auth = await authed();
  if (!auth.user) return auth.response;
  const { action } = await params;
  const limited = rateLimit(`${auth.user.id}:paypal:${action}:${requestIp(request)}`, 30);
  if (!limited.allowed) return fail("Too many payment requests. Please wait before retrying.", 429, { retryAfterSeconds: limited.retryAfter });
  const body = await readJson(request);

  if (action === "status") {
    const invoiceId = str(body.invoiceId);
    const orderId = str(body.orderId);
    if (!isUuid(invoiceId) || !orderId) return fail("A valid invoice and PayPal order are required.");
    const [invoice] = await db.select().from(invoices).where(and(eq(invoices.id, invoiceId), eq(invoices.userId, auth.user.id))).limit(1);
    if (!invoice) return fail("Invoice not found.", 404);
    if (invoice.paypalOrderId !== orderId) return fail("This order does not belong to this invoice.", 403);
    try {
      const status = await getPayPalOrderStatus(orderId);
      return ok({ mode: orderId.startsWith("DEMO-") ? "demo" : "live", ...status, invoiceStatus: invoice.status, message: "Read-only PayPal status check. Invoice status changes only after a verified capture." });
    } catch (error) {
      return fail(error instanceof Error ? error.message : "Unable to verify PayPal order status.", 502);
    }
  }

  if (action === "create-order") {
    const invoiceId = str(body.invoiceId);
    if (!isUuid(invoiceId)) return fail("A valid invoice is required.");
    const [invoice] = await db.select().from(invoices)
      .where(and(eq(invoices.id, invoiceId), eq(invoices.userId, auth.user.id))).limit(1);
    if (!invoice) return fail("Invoice not found.", 404);
    if (["draft", "void"].includes(invoice.status)) return fail("Issue the invoice before requesting payment.");

    const ledger = await loadLedger(auth.user.id);
    if (!ledger) return fail("Business profile not found.", 404);
    const source = ledger.invoices.find((item) => item.id === invoiceId);
    if (!source) return fail("Invoice not found.", 404);
    const dto = toInvoiceDTO(ledger, source);
    if (dto.balance <= 0.01) return fail("This invoice is already settled.");

    try {
      const origin = publicOrigin(request);
      const order = await createPayPalOrder({
        amount: dto.balance,
        currency: ledger.business.currency || "USD",
        description: `Invoice ${invoice.number}`,
        reference: invoice.number,
        returnUrl: `${origin}/payments?paypal=success&invoice=${invoice.id}`,
        cancelUrl: `${origin}/payments?paypal=cancelled&invoice=${invoice.id}`,
      });
      await db.update(invoices).set({ paypalOrderId: order.orderId })
        .where(and(eq(invoices.id, invoice.id), eq(invoices.userId, auth.user.id)));

      await logActivity(auth.user.id, "payment",
        order.mode === "demo" ? "Created a simulated PayPal order" : "Created a PayPal checkout order",
        "info", order.mode === "demo"
          ? "Demo checkout is a simulation only. It will not settle the invoice or change real cash figures."
          : `Order ${order.orderId} created for ${dto.balance.toFixed(2)} ${ledger.business.currency}.`,
        { orderId: order.orderId, mode: order.mode });

      return ok({
        mode: order.mode,
        orderId: order.orderId,
        approveUrl: order.approveUrl,
        amount: dto.balance,
        currency: ledger.business.currency,
        message: order.mode === "demo"
          ? "PayPal credentials are unavailable. Demo checkout can record a simulated transaction, but no money moves and your invoice stays unpaid."
          : "Approve the order in PayPal, then capture it on your Payments page.",
      });
    } catch (error) {
      return fail(error instanceof Error ? error.message : "Unable to create PayPal order.", 502);
    }
  }

  if (action === "capture") {
    const orderId = str(body.orderId);
    const invoiceId = str(body.invoiceId);
    if (!orderId || !isUuid(invoiceId)) return fail("A valid order and invoice are required.");

    const [invoice] = await db.select().from(invoices)
      .where(and(eq(invoices.id, invoiceId), eq(invoices.userId, auth.user.id))).limit(1);
    if (!invoice) return fail("Invoice not found.", 404);
    if (invoice.paypalOrderId !== orderId) return fail("This order does not belong to this invoice.", 403);

    const [existing] = await db.select().from(payments)
      .where(and(eq(payments.paypalOrderId, orderId), eq(payments.userId, auth.user.id))).limit(1);
    if (existing) return ok({
      mode: existing.status === "simulated" ? "demo" : paypalConfig()?.mode ?? "sandbox",
      status: existing.status.toUpperCase(),
      transactionId: existing.transactionId,
      amount: Number(existing.amount),
      alreadyRecorded: true,
      message: "This PayPal order was already recorded. No duplicate payment was created.",
    });

    const demo = orderId.startsWith("DEMO-");
    if (demo && body.confirmDemo !== true) return fail("Confirm demo mode before simulating a capture.", 400);
    if (demo && paypalConfigured()) return fail("A demo order cannot be captured while PayPal is configured.", 400);
    if (!demo && !paypalConfigured()) return fail("PayPal credentials are required to verify this order.", 503);

    const ledger = await loadLedger(auth.user.id);
    if (!ledger) return fail("Business profile not found.", 404);
    const source = ledger.invoices.find((item) => item.id === invoiceId);
    if (!source) return fail("Invoice not found.", 404);
    const dto = toInvoiceDTO(ledger, source);
    if (dto.balance <= 0.01) return fail("This invoice is already settled.", 409);

    try {
      const capture = await capturePayPalOrder(orderId);
      if (!demo && capture.status !== "COMPLETED") return fail("PayPal has not completed this payment.", 409);
      if (!demo && capture.currency !== ledger.business.currency) return fail("PayPal returned a different currency. The invoice was not changed.", 409);
      if (!demo && Math.abs(capture.amount - dto.balance) > 0.01) return fail("Captured amount differs from the outstanding balance. Reconcile this payment manually.", 409);
      const amount = demo ? dto.balance : round2(capture.amount);
      if (amount <= 0) return fail("The captured amount must be positive.");

      const payment = await db.transaction(async (tx) => {
        const [locked] = await tx.select().from(invoices)
          .where(and(eq(invoices.id, invoiceId), eq(invoices.userId, auth.user.id)))
          .for("update").limit(1);
        if (!locked || locked.paypalOrderId !== orderId) throw new Error("The order changed during capture. Please refresh.");
        const [duplicate] = await tx.select({ id: payments.id }).from(payments)
          .where(eq(payments.paypalOrderId, orderId)).limit(1);
        if (duplicate) throw new Error("This order was already captured.");
        const settled = await tx.select({ amount: payments.amount }).from(payments)
          .where(and(eq(payments.invoiceId, invoiceId), eq(payments.status, "completed")));
        const alreadyPaid = round2(settled.reduce((sum, row) => sum + Number(row.amount), 0));
        const remaining = round2(Number(locked.total) - alreadyPaid);
        if (remaining <= 0.01) throw new Error("The invoice was settled before this capture was recorded.");
        if (!demo && amount > remaining + 0.01) throw new Error("Captured payment exceeds the outstanding invoice balance.");

        const [record] = await tx.insert(payments).values({
          userId: auth.user.id,
          invoiceId: locked.id,
          clientId: locked.clientId,
          amount: money(amount),
          method: demo ? "paypal_demo" : "paypal",
          status: demo ? "simulated" : "completed",
          transactionId: capture.transactionId || orderId,
          paypalOrderId: orderId,
          note: demo ? "Simulation only — no real funds moved, invoice remains unpaid" : "Captured and verified via PayPal",
          paidAt: today(),
        }).returning();

        if (!demo) {
          const newPaid = round2(alreadyPaid + amount);
          await tx.update(invoices).set({
            amountPaid: money(newPaid),
            status: newPaid >= Number(locked.total) - 0.01 ? "paid" : "partially_paid",
          }).where(eq(invoices.id, locked.id));
        }
        return record;
      });

      await logActivity(auth.user.id, "payment",
        demo ? "Recorded a PayPal demo simulation" : "Captured and reconciled a PayPal payment",
        demo ? "info" : "success",
        demo ? `Simulated ${amount.toFixed(2)} for ${invoice.number}. No funds moved and the invoice remains open.`
          : `${amount.toFixed(2)} ${ledger.business.currency} applied to ${invoice.number}. Transaction ${payment.transactionId}.`,
        { orderId, transactionId: payment.transactionId, demo });

      await notify(
        auth.user.id,
        demo ? `Payment simulation · ${invoice.number}` : `Payment captured · ${invoice.number}`,
        demo
          ? `A simulated ${amount.toFixed(2)} transaction was recorded. No funds moved and the invoice remains unpaid.`
          : `${amount.toFixed(2)} ${ledger.business.currency} was captured via PayPal. Transaction ${payment.transactionId}.`,
        demo ? "info" : "success",
      );
      const fresh = await loadLedger(auth.user.id);
      const row = fresh?.invoices.find((item) => item.id === invoiceId);
      return ok({
        mode: demo ? "demo" : "live",
        status: demo ? "SIMULATED" : "COMPLETED",
        transactionId: payment.transactionId,
        amount,
        invoice: fresh && row ? toInvoiceDTO(fresh, row) : null,
        message: demo
          ? "Demo transaction simulated. No money moved; your real cash balance and invoice status are unchanged."
          : "PayPal payment verified, captured and applied to the invoice.",
      });
    } catch (error) {
      if (!orderId.startsWith("DEMO-")) {
        await notify(auth.user.id, `Payment needs attention · ${invoice.number}`, "PayPal did not confirm a completed capture. The invoice was not marked paid. Review the order in PayPal and retry.", "warning");
      }
      return fail(error instanceof Error ? error.message : "Unable to capture the PayPal payment.", 409);
    }
  }

  return fail("Unknown PayPal action.", 404);
}
