import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowDownToLine, ArrowLeft, ArrowUpRight, CheckCircle2, Clock3, FileText, ShieldCheck } from "lucide-react";
import { BearMark } from "@/components/BearMark";
import { getSharedInvoice } from "@/lib/share";
import { formatDate, formatMoney, titleCase } from "@/lib/format";

type Props = { params: Promise<{ token: string }> };

export default async function SharedInvoicePage({ params }: Props) {
  const { token } = await params;
  const shared = await getSharedInvoice(token);
  if (!shared) notFound();
  const { business, invoice, clientEmail, clientAddress } = shared;
  const money = (amount: number) => formatMoney(amount, business.currency);
  const discount = invoice.discountType === "percent"
    ? Math.round(invoice.subtotal * invoice.discountValue) / 100
    : Math.min(invoice.subtotal, invoice.discountValue);
  const tax = Math.max(0, invoice.total - invoice.subtotal + discount);
  const settled = invoice.balance <= 0.01;

  return (
    <div className="min-h-screen bg-[#f6f8fc] text-navy">
      <header className="border-b border-slate-200 bg-white">
        <div className="mx-auto flex max-w-5xl items-center justify-between gap-3 px-4 py-4 sm:px-7">
          <Link href="/" className="flex items-center gap-2.5"><span className="flex h-9 w-9 items-center justify-center rounded-xl bg-brand text-white"><BearMark className="h-[18px] w-[18px]" /></span><span className="font-display text-[14px] font-extrabold tracking-tight">PayPilot <span className="text-brand">AI</span></span></Link>
          <span className="flex items-center gap-1.5 text-[11px] font-semibold text-slate-500"><ShieldCheck className="h-3.5 w-3.5 text-brand" />Secure invoice view</span>
        </div>
      </header>

      <main className="mx-auto max-w-5xl px-4 py-8 sm:px-7 sm:py-12">
        <div className="mb-5 flex flex-wrap items-center justify-between gap-3"><div><p className="text-[11px] font-bold uppercase tracking-[.14em] text-brand">INVOICE / {invoice.number}</p><h1 className="mt-1 font-display text-2xl font-extrabold tracking-tight sm:text-[30px]">Invoice from {business.name}</h1><p className="mt-1 text-[13px] text-slate-500">Issued {formatDate(invoice.issueDate)} · Due {formatDate(invoice.dueDate)}</p></div><a href={`/api/share/${token}/pdf`} className="btn btn-secondary"><ArrowDownToLine className="h-4 w-4" />Download PDF</a></div>

        {business.isDemo && <div className="mb-5 rounded-xl border border-[#f2e1b0] bg-[#fffaf0] px-4 py-3 text-[12px] font-medium text-[#98671f]">This is a sample invoice from a demo workspace. No real payment is due or processed.</div>}

        <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_260px]">
          <div className="card overflow-hidden !p-0">
            <div className="h-2 bg-gradient-to-r from-brand via-[#5b80ff] to-[#9aafff]" />
            <div className="p-5 sm:p-8">
              <div className="flex flex-wrap justify-between gap-5 border-b border-slate-100 pb-7"><div><p className="text-[10px] font-extrabold uppercase tracking-[.15em] text-slate-400">FROM</p><p className="mt-2 font-display text-[17px] font-extrabold text-navy">{business.name}</p><p className="mt-1 text-[12px] text-slate-500">{business.country}</p><p className="text-[12px] text-slate-500">{business.email}</p></div><div className="sm:text-right"><p className="text-[10px] font-extrabold uppercase tracking-[.15em] text-slate-400">BILL TO</p><p className="mt-2 font-display text-[17px] font-extrabold text-navy">{invoice.clientName}</p>{clientEmail && <p className="mt-1 text-[12px] text-slate-500">{clientEmail}</p>}{clientAddress && <p className="max-w-52 text-[12px] text-slate-500">{clientAddress}</p>}</div></div>

              <div className="mt-7 overflow-x-auto"><table className="w-full min-w-[420px] text-left text-[12px]"><thead><tr className="border-b border-slate-200 text-[10px] font-extrabold uppercase tracking-[.09em] text-slate-400"><th className="pb-3">Description</th><th className="pb-3 text-right">Qty</th><th className="pb-3 text-right">Unit price</th><th className="pb-3 text-right">Amount</th></tr></thead><tbody className="divide-y divide-slate-100">{invoice.items.map((item, index) => <tr key={item.id || index}><td className="py-4 font-semibold text-navy">{item.description}</td><td className="py-4 text-right text-slate-600">{item.quantity}</td><td className="py-4 text-right text-slate-600">{money(item.unitPrice)}</td><td className="py-4 text-right font-bold text-navy">{money(item.amount)}</td></tr>)}</tbody></table></div>

              <div className="mt-6 ml-auto max-w-[290px] space-y-2 border-t border-slate-100 pt-5 text-[12px]"><div className="flex justify-between text-slate-500"><span>Subtotal</span><span className="font-semibold text-navy">{money(invoice.subtotal)}</span></div>{discount > 0 && <div className="flex justify-between text-slate-500"><span>Discount {invoice.discountType === "percent" && `(${invoice.discountValue}%)`}</span><span>−{money(discount)}</span></div>}{invoice.taxRate > 0 && <div className="flex justify-between text-slate-500"><span>Tax ({invoice.taxRate}%)</span><span>{money(tax)}</span></div>}<div className="flex justify-between border-t border-slate-200 pt-3 text-[15px] font-extrabold text-navy"><span>Total</span><span>{money(invoice.total)}</span></div>{invoice.amountPaid > 0 && <div className="flex justify-between text-[#07865d]"><span>Amount paid</span><span>−{money(invoice.amountPaid)}</span></div>}<div className="flex justify-between rounded-xl bg-brand-soft px-3 py-3 text-[14px] font-extrabold text-brand"><span>Balance due</span><span>{money(invoice.balance)}</span></div></div>

              {invoice.notes && <div className="mt-8 border-t border-slate-100 pt-5"><p className="text-[10px] font-extrabold uppercase tracking-[.14em] text-slate-400">NOTES & PAYMENT TERMS</p><p className="mt-2 whitespace-pre-wrap text-[12px] leading-relaxed text-slate-600">{invoice.notes}</p></div>}
            </div>
          </div>

          <div className="space-y-4"><div className="card p-5"><span className={`flex h-10 w-10 items-center justify-center rounded-xl ${settled ? "bg-mint-soft text-[#07865d]" : "bg-brand-soft text-brand"}`}>{settled ? <CheckCircle2 className="h-5 w-5" /> : <Clock3 className="h-5 w-5" />}</span><p className="mt-4 text-[10px] font-extrabold uppercase tracking-[.13em] text-slate-400">PAYMENT STATUS</p><p className="mt-1 font-display text-[21px] font-extrabold capitalize">{titleCase(invoice.status)}</p><p className="mt-2 text-[12px] leading-relaxed text-slate-500">{settled ? "The balance on this invoice has been paid in full." : `The remaining balance of ${money(invoice.balance)} is due on ${formatDate(invoice.dueDate)}.`}</p></div><div className="card p-5"><FileText className="h-5 w-5 text-brand" /><p className="mt-3 text-[13px] font-bold">Questions about this invoice?</p><p className="mt-1 text-[12px] leading-relaxed text-slate-500">Contact the issuer directly about payment terms or the services listed here.</p>{business.email && !business.isDemo && <a href={`mailto:${business.email}?subject=${encodeURIComponent(`Invoice ${invoice.number}`)}`} className="mt-4 inline-flex items-center gap-1 text-[12px] font-bold text-brand hover:underline">Email {business.name}<ArrowUpRight className="h-3.5 w-3.5" /></a>}</div><p className="px-1 text-[10px] leading-relaxed text-slate-400">Only people with this secure link can view this invoice. The owner may revoke access at any time. PayPilot does not process payments on this page.</p></div>
        </div>
        <Link href="/" className="mt-7 inline-flex items-center gap-1.5 text-[11px] font-semibold text-slate-500 hover:text-brand"><ArrowLeft className="h-3.5 w-3.5" />Powered by PayPilot AI</Link>
      </main>
    </div>
  );
}
