import type { Metadata } from "next";
import type { ReactNode } from "react";
import "@fontsource-variable/dm-sans/wght.css";
import "@fontsource-variable/plus-jakarta-sans/wght.css";
import "./globals.css";

export const metadata: Metadata = {
  title: "PayPilot AI — Your Autonomous Finance Assistant",
  description:
    "PayPilot AI is an AI-powered financial management platform for freelancers, startups and small businesses, with five collaborating finance agents.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-[#f6f7fb] text-navy antialiased">{children}</body>
    </html>
  );
}
