import { redirect } from "next/navigation";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { businesses } from "@/db/schema";
import { OnboardingForm } from "@/components/OnboardingForm";
import { getSessionUser } from "@/lib/auth";

export default async function OnboardingPage() {
  const user = await getSessionUser();
  if (!user) redirect("/login");

  const [business] = await db.select().from(businesses).where(eq(businesses.userId, user.id)).limit(1);
  if (business?.onboardingComplete) redirect("/overview");

  return (
    <div className="flex min-h-screen items-center justify-center bg-[#f6f7fb] px-4 py-10">
      <div className="w-full max-w-2xl">
        <OnboardingForm
          initial={{
            name: business?.name && !business.name.includes("'s Business") ? business.name : "",
            email: business?.email || user.email,
          }}
        />
      </div>
    </div>
  );
}
